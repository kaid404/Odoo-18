from odoo import models, api, fields
from datetime import date, timedelta, datetime, date
from calendar import monthrange
import calendar
from odoo.exceptions import ValidationError
import math
import logging

_logger = logging.getLogger(__name__)


class BulkLeaveEncashment(models.TransientModel):
    _name = 'bulk.leave.encashment'

    department_ids = fields.Many2many('hr.department', string='Departments')
    period_id = fields.Many2one('monal.evaluation.period', string='Period', required=True)
    employee_ids = fields.One2many('bulk.leave.encashment.line', 'wizard_id', string='Employees')

    @api.onchange('department_ids', 'period_id')
    def _onchange_department_ids(self):
        if not self.period_id:
            self.employee_ids = [(5, 0, 0)]
            return

        start_date = self.period_id.period_start_date
        end_date = self.period_id.period_end_date

        # Build domain
        domain = [('company_id', '=', self.env.company.id)]
        if self.department_ids:
            domain.append(('department_id', 'in', self.department_ids.ids))

        employees = self.env['hr.employee'].search(domain)

        lines = []
        for emp in employees:
            # Attendance count in period
            attendance_count = self.env['hr.attendance'].search_count([
                ('employee_id', '=', emp.id),
                ('check_in', '>=', start_date),
                ('check_in', '<=', end_date),
            ])

            if attendance_count <= 0:
                continue  # skip if not eligible

            # Weekly Off allocation
            leave_allocation = self.env['hr.leave.allocation'].search([
                ('employee_id', '=', emp.id),
                ('holiday_status_id.name', '=', 'Weekly Off'),
                ('state', '=', 'validate')
            ], limit=1)

            remaining = 0.0
            if leave_allocation:
                taken_leaves = self.env['hr.leave'].search([
                    ('employee_id', '=', emp.id),
                    ('holiday_status_id', '=', leave_allocation.holiday_status_id.id),
                    ('state', '=', 'validate'),
                    ('request_date_from', '>=', start_date),
                    ('request_date_to', '<=', end_date),
                ])
                remaining = leave_allocation.number_of_days_display - sum(taken_leaves.mapped('number_of_days'))
            if remaining > 0:
                lines.append((0, 0, {
                    'employee_id': emp.id,
                    'attendance_count': attendance_count,
                    'remaining_weekly_off': remaining,
                }))

        # Always reset lines, then add new
        self.employee_ids = [(5, 0, 0)] + lines

    def action_cancel_wizard(self):
        pass

    def action_confirm_bulk_encashment(self):
        for wizard in self:
            vals_list = []
            for line in wizard.employee_ids:
                vals = {
                    'em_p': line.employee_id.id,
                    'period': wizard.period_id.id,
                    'amount': line.encashment_amount,
                    'encashed_amount': line.encashed_amount,
                    'tree_line': [
                    (0, 0, {
                        'employee_id': line.employee_id.id,
                        'encash_leaves': line.leave_to_encash,
                    })
                ],
                }
                vals_list.append(vals)
            if vals_list:
                self.env['leave.encashment'].create(vals_list)



class BulkLeaveEncashmentLine(models.TransientModel):
    _name = 'bulk.leave.encashment.line'

    wizard_id = fields.Many2one('bulk.leave.encashment', string='Wizard')
    employee_id = fields.Many2one('hr.employee', string='Employee', required=True)
    attendance_count = fields.Integer("Present Days")
    remaining_weekly_off = fields.Float("Remaining LEaves")
    leave_to_encash = fields.Float("Leaves To Encash")
    encashment_amount = fields.Float("Total Amount", compute="_compute_encashment_amount", store=False)
    encashed_amount = fields.Float(string="Encashed Amount", compute="_compute_encashment_amount_for_leaves")

    @api.depends('employee_id', 'leave_to_encash')
    def _compute_encashment_amount_for_leaves(self):
        for rec in self:
            if rec.employee_id:
                wage = rec.employee_id.contract_id.wage  # from latest running contract
                rec.encashed_amount = (wage / 30.0) * rec.leave_to_encash
            else:
                rec.encashed_amount = 0.0
           

    @api.depends('employee_id', 'remaining_weekly_off')
    def _compute_encashment_amount(self):
        for rec in self:
            if rec.employee_id.contract_id and rec.remaining_weekly_off > 0:
                wage = rec.employee_id.contract_id.wage  # from latest running contract
                rec.encashment_amount = (wage / 30.0) * rec.remaining_weekly_off
            else:
                rec.encashment_amount = 0.0
