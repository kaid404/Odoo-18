from odoo import models, api, fields, _
from odoo.exceptions import ValidationError
from datetime import datetime, timedelta, date
import logging
from dateutil.relativedelta import relativedelta

from odoo.addons.stock.report.stock_traceability import autoIncrement

# from odoo.odoo.api import ondelete

_logger = logging.getLogger(__name__)


class LeaveCashment(models.Model):
    _name = "leave.encashment"

    em_p = fields.Many2one('hr.employee', string="Employee", required=True)
    total_leave = fields.Float(string="Total Leave")
    re_leave = fields.Float(string="Remaining leaves")
    amount = fields.Float(string="Amount")
    state = fields.Selection([
        ('draft', 'Draft'),
        ('submit_to_approve', 'Submit To Approve'),
        ('approve', 'Approve'),
        ('reject', 'Reject'),
    ], default='draft', string="State")
    tree_line = fields.One2many('leave.encashment.tree', 'connecting_field', string='Allocations')
    notice_date = fields.Date(string='Notice Date')
    period = fields.Many2one('monal.evaluation.period', string='Period', required=True)
    encashed_amount = fields.Float(string="Encashed Amount", compute="_compute_encashed_amount")
    populate = fields.Boolean(string="Populate")

    @api.depends('tree_line.encash_leaves', 'em_p.contract_ids', 'period')
    def _compute_encashed_amount(self):
        for rec in self:
            contract_id = rec.em_p.contract_ids.filtered(lambda x: x.state == 'open')
            contract = contract_id.wage if contract_id else 0.0

            if contract and rec.period:
                daily_wage = contract / 30
                total_encashed = sum(line.encash_leaves for line in rec.tree_line)
                rec.encashed_amount = daily_wage * total_encashed
            else:
                rec.encashed_amount = 0.0

    def _get_leave_end_date(self, start_date, days_to_encash):
        days_counted = 0
        current_date = start_date

        while days_counted < days_to_encash:
            if current_date.weekday() != 6:  # 6 = Sunday
                days_counted += 1
            if days_counted < days_to_encash:
                current_date += timedelta(days=1)

        return current_date

    def action_approve_encashment(self):
        for rec in self:
            total_encashed_leaves = 0.0

            # Find the latest encashed leave for this employee & period
            last_encashed_leave = self.env['hr.leave'].search([
                ('employee_id', '=', rec.em_p.id),
                ('holiday_status_id', 'in', rec.tree_line.mapped('holiday_status_id').ids),
                ('state', '=', 'validate'),
                ('leave_encashed_check', '=', True),
                ('request_date_from', '>=', rec.period.period_start_date),
                ('request_date_to', '<=', rec.period.period_end_date),
            ], order="request_date_to desc", limit=1)

            if last_encashed_leave:
                current_start_date = last_encashed_leave.request_date_to + timedelta(days=1)
            else:
                current_start_date = rec.period.period_start_date  # start fresh

            for line in rec.tree_line:
                if line.encash_leaves:
                    if line.encash_leaves > line.duration_display:
                        raise ValidationError(_(
                            "You cannot encash more than available leaves for %s. Available: %s"
                        ) % (line.name, line.duration_display))

                    # Deduct from balance
                    line.duration_display -= line.encash_leaves
                    total_encashed_leaves += line.encash_leaves

                    # Calculate end date for this leave encashment
                    date_from = current_start_date
                    date_to = self._get_leave_end_date(date_from, line.encash_leaves)

                    # Create leave record
                    leave = self.env['hr.leave'].create({
                        'name': 'Encashment - %s' % line.name,
                        'employee_id': rec.em_p.id,
                        'holiday_status_id': line.holiday_status_id.id,
                        'request_date_from': date_from,
                        'request_date_to': date_to,
                        'number_of_days': line.encash_leaves,
                        'state': 'confirm',
                    })
                    leave.action_approve()
                    leave.action_validate()
                    leave.leave_encashed_check = True

                    # Update current_start_date to the next day after this leave's end date
                    current_start_date = date_to + timedelta(days=1)

            rec.state = 'approve'

    def action_reject_encashment(self):
        self.state = 'reject'

    def action_sumbit_to_encashment(self):
        for rec in self:
            for line in rec.tree_line:
                if line.encash_leaves <= 0:
                    raise ValidationError(_(
                        "Encash Leave could not be 0"))
        self.state = 'submit_to_approve'

    def action_post(self):
        """Populate tree_line based on attendance > 26 in given period"""
        for rec in self:
            if not rec.em_p or not rec.period:
                raise ValidationError(_("Please select Employee and Period first."))

            start_date = rec.period.period_start_date
            end_date = rec.period.period_end_date

            if not start_date or not end_date:
                raise ValidationError(_("Selected Period does not have valid dates."))

            # Count attendance (present days)
            present_days = self.env['hr.attendance'].search_count([
                ('employee_id', '=', rec.em_p.id),
                ('check_in', '>=', start_date),
                ('check_in', '<=', end_date),
            ])

            if present_days <= 0:
                raise ValidationError(
                    _("Employee %s has only %s present days in this period. Minimum required is 27.") %
                    (rec.em_p.name, present_days)
                )

            # Clear old lines
            rec.tree_line = [(5, 0, 0)]

            # Leave types marked encashable
            leave_types = self.env['hr.leave.type'].search([('leave_encash', '=', True)])
            today = fields.Date.today()
            vals = []

            for leave_type in leave_types:
                # Allocations
                allocations = self.env['hr.leave.allocation'].search([
                    ('employee_id', '=', rec.em_p.id),
                    ('holiday_status_id', '=', leave_type.id),
                    ('state', '=', 'validate'),
                ]).mapped('number_of_days')

                # Already used
                used = self.env['hr.leave'].search([
                    ('employee_id', '=', rec.em_p.id),
                    ('holiday_status_id', '=', leave_type.id),
                    ('state', '=', 'validate'),
                ]).mapped('number_of_days')

                duration_display = sum(allocations) - sum(used)
                contract_id = rec.em_p.contract_ids.filtered(lambda x: x.state == 'open')
                contract = contract_id.wage
                # contract = record.em_p.contract_id.wage
                if contract and rec.period:
                    daily_wage = contract / 30
                    rec.amount = daily_wage * duration_display
                else:
                    rec.amount = 0

                if duration_display > 0:
                    vals.append((0, 0, {
                        'employee_id': rec.em_p.id,
                        'holiday_status_id': leave_type.id,
                        'name': present_days,
                        'duration_display': duration_display,
                    }))

            rec.tree_line = vals
            rec.populate = True

    def unlink(self):
        if self.state != "draft":
            raise ValidationError(_("You cannot Delete Record if state is not draft"))
        return super().unlink()




class LeaveEncashmentTree(models.Model):
    _name = "leave.encashment.tree"

    connecting_field = fields.Many2one('leave.encashment', string='Connecting Field')
    employee_id = fields.Many2one('hr.employee', string='Employee')
    holiday_status_id = fields.Many2one('hr.leave.type', string='Time Off Type')
    name = fields.Char(string='Work Days')
    duration_display = fields.Float(string='Available Leaves')
    encash_leaves = fields.Float(string='Leaves to Encash')


class HRLeaveType(models.Model):
    _inherit = "hr.leave.type"

    leave_encash = fields.Boolean(string="Leave Encashment", store=True, trackuing=True)


class HRLeave(models.Model):
    _inherit = "hr.leave"

    leave_encashed_check = fields.Boolean(string="Leave Encashed", store=True, trackuing=True)
