from odoo import api, fields, models, _
from odoo.osv import expression



class HrPayslipEmployees(models.TransientModel):
    _inherit = 'hr.payslip.employees'
    _description = 'Generate payslips for all selected employees'


    campus_field = fields.Selection([('school', 'School'), ('college', 'College')], default=False, string='Campus')
    campus_school = fields.Many2many('gxs.campus', string='School')
    campus_college = fields.Many2many('odoocms.campus', string='College')

    @api.depends(
        'structure_id',
        'department_id',
        'structure_type_id',
        'job_id',
        'campus_field',
        'campus_school',
        'campus_college'
    )
    def _compute_employee_ids(self):
        for wizard in self:
            domain = wizard.get_employees_domain()
            wizard.employee_ids = self.env['hr.employee'].search(domain)


    def get_employees_domain(self):
        self.ensure_one()
        # domain = super(HrPayslipEmployees, self).get_employees_domain()
        domain = super().get_employees_domain()

        if self.campus_field == 'school' and self.campus_school:
            domain += [('school_campus_id', 'in', self.campus_school.ids)]

        elif self.campus_field == 'college' and self.campus_college:
            domain += [('campus_id', 'in', self.campus_college.ids)]

            # domain = expression.AND([
            #     domain,
            #     [('campus_id', 'in', self.campus_college.ids)]
            # ])
        print(domain)
        return domain


