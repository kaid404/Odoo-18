{
    'name': 'Campus Field',
    'version': '18.0',
    'summary': """Campus Field""",
    'description': 'Campus Field',
    'author': 'Ali',
    'category': 'Other',
    'depends': ['hr_payroll'],

    'data': [
        'views/campus_field.xml',
    ],
    'installable': True,
    'auto_install': False,
    'application': False,
}
