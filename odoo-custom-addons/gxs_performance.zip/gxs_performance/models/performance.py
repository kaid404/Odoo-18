from odoo import models, fields, api


class PerformanceTemplate(models.Model):
    _name = 'gxs.performance.template'
    _description = 'Performance Template'
    _inherit = ['mail.thread', 'mail.activity.mixin']

    name = fields.Char(string="Name")
    code = fields.Char(string="Code")
    performance_template_line_ids = fields.One2many('gxs.performance.template.line', 'template_id',
                                                    string='Performance Grade')
    performance_template_sublines = fields.One2many('gxs.performance.template.subline', 'template_id',
                                                    string='Performance Sublines')
    performance_template_detail_ids = fields.One2many('gxs.performance.template.detail', 'template_id',
                                                    string='Performance Details')


class PerformanceTemplateLine(models.Model):
    _name = 'gxs.performance.template.line'
    _description = 'Performance Template Lines'
    _order = 'sequence'

    sequence = fields.Integer('Sequence')
    name = fields.Char('Name', required=True)
    line_code = fields.Char('Code', required=True)
    exam_type = fields.Many2one('op.exam.type', 'Exam Type', required=True)
    template_id = fields.Many2one('gxs.performance.template', 'Performance Template')
    section_id = fields.Many2one('class.section', string="Section")
    std_performance_id = fields.Many2one("gxs.std.performance", string="STD Performance")
    std_result_id = fields.Many2one('gxs.std.result', string="Results ID")

    performance_sublines = fields.One2many('gxs.performance.template.subline', 'performance_id', string='Performance Sublines')

    # line_revers_id = fields.Many2one('gxs.performance.template.line',string='Line revers',compute='_compute_performance_detail_line_ids',store=True)
    #
    #
    #
    #
    # performance_detail_line_ids = fields.One2many(
    #     'gxs.performance.template.detail',
    #     'performance_id',
    #     string='Performance Details',
    #     store=True
    # )

    # @api.depends('name')
    # def _compute_performance_detail_line_ids(self):
    #     print('working start')
    #     for rec in self:
    #         if rec.line_revers_id:
    #             print('wwwww')
    #             for i in rec.line_revers_id.performance_detail_line_ids:
    #                 print(i)
    #                 copy_line = i.copy()
    #                 print(copy_line)
    #                 copy_line.performance_id = rec.id




        #
        # for line in self:
        #     results = self.env['gxs.performance.template.detail'].search([
        #         ('performance_id.name', '=', line.name),
        #         ('performance_id.line_code', '=', line.line_code)
        #     ])
        #
        #     print(results)
        #     line.performance_detail_line_ids = self.env['gxs.performance.template.detail'].search([
        #         ('performance_id.name', '=', line.name),
        #         ('performance_id.line_code', '=', line.line_code)
        #     ])




class PerformanceTemplateDetails(models.Model):
    _name = 'gxs.performance.template.detail'
    _description = 'Performance Template Details'

    sequence = fields.Integer('Sequence')
    name = fields.Char(string="Name")
    performance_type = fields.Selection([
        ('E', 'E'),
        ('G', 'G'),
        ('S', 'S'),
        ('NI', 'NI'),
    ], string="Type")

    template_id = fields.Many2one('gxs.performance.template', 'Performance Template')
    performance_id = fields.Many2one('gxs.performance.template.line', 'Performance Lines')
    std_performance_id = fields.Many2one("gxs.std.performance", string="STD Performance")



class PerformanceTemplateSublines(models.Model):
    _name = 'gxs.performance.template.subline'
    _description = 'Performance Template Sublines'

    name = fields.Char(string="Name")

    template_id = fields.Many2one('gxs.performance.template', 'Performance Template')
    performance_id = fields.Many2one('gxs.performance.template.line', 'Performance Lines')

