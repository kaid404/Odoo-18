from odoo import api, models, fields, api


class StudentPerformance(models.Model):
    _name = "performance.result.lines"

    name = fields.Char('Name', required=True)
    exam_type = fields.Many2one('op.exam.type', 'Exam Type', required=True)

    std_result_id = fields.Many2one('gxs.std.result')


    def open_details(self):
        pass

    def action_result(self):
        return {
            'type': "ir.actions.act_window",
            'view_type': 'form',
            'view_mode': "list,form",
            'res_model': "",
            'domain': [('std_performance_line_id', '=', self.id)]
        }