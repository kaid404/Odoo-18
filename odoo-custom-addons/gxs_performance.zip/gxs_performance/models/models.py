from odoo import models, fields, api


class ClassSection(models.Model):
    _inherit = "class.section"

    gxs_performance_ids = fields.Many2one('gxs.performance.template', string='Performance')
    gxs_section_performance_line_ids = fields.One2many('gxs.performance.template.line', 'section_id',
                                                       string="Performance Lines")

    @api.constrains('gxs_performance_ids')
    def _onchange_performance_ids(self):
        if self.gxs_performance_ids:
            self.gxs_section_performance_line_ids = [(5, 0, 0)]
            new_lines = []
            for line in self.gxs_performance_ids.performance_template_line_ids:
                new_lines.append((0, 0, {
                    'name': line.name,
                    'line_code': line.line_code,
                    'exam_type': line.exam_type.id,
                }))
            self.gxs_section_performance_line_ids = new_lines


class StudentPerformance(models.Model):
    _inherit = "gxs.std.performance"

    gxs_section_performance_line_ids = fields.One2many('gxs.performance.template.line', 'std_performance_id',
                                                       string="Performance Lines")

    @api.onchange('section_id')
    def _onchange_section_id(self):
        if self.section_id:
            self.gxs_section_performance_line_ids = [(5, 0, 0)]
            new_lines = []
            for line in self.section_id.gxs_section_performance_line_ids:
                new_lines.append((0, 0, {
                    'name': line.name,
                    'line_code': line.line_code,
                    'exam_type': line.exam_type,
                }))
            self.gxs_section_performance_line_ids = new_lines



