{
    'name': "Student Performance",
    'author': "Khalid",
	'Maintainer': 'Global XS Technology Solutions',
	'category': 'Studio',
    'license': 'AGPL-3',
    'description': """Student Performance""",
    'version': '18.0',
    'depends': ['gxs_core', 'odoocms_academic', 'mail', 'gxs_student_performance'],
    'data': [
        'security/ir.model.access.csv',
        'views/subject_views.xml',
        'views/performance_views.xml',
        ],
    'installable': True,
    'application': True,
    'auto_install': False,
}
