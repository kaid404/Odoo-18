from odoo import models, fields, api


class AdditionalDuties(models.Model):
    _name = 'additional.duties'

    duties_name = fields.Many2one('hr.employee', string='Name', required=True)
    duties_job = fields.Many2one('hr.job', compute='compute_emp_details',string='Job Position')
    duties_department = fields.Many2one('hr.department', compute='compute_emp_details',string='Department')
    duties_additional = fields.Text(string="Additional Duties")


    additional_duties_emp_id = fields.Many2one('hr.employee')

    @api.onchange('duties_name')
    def compute_emp_details(self):
        for rec in self:
            if rec.duties_name:
                rec.duties_job = rec.duties_name.job_id
                rec.duties_department = rec.duties_name.department_id

class HrEmployee(models.Model):
    _inherit = 'hr.employee'

    additional_duties_emp_ids = fields.One2many('additional.duties', 'additional_duties_emp_id')

