# -*- coding: utf-8 -*-

{
    'name': "Employee Personal Details Management",

    'summary': "Module for adding fields in personal information of Employee",

    'description': """Module for adding fields in personal information of Employee""",

    'author': "Khalid",
    'version': '18.0',
    'depends': ['base', 'hr'],

    # always loaded
    'data': [
        'security/ir.model.access.csv',
        'views/personal_info_views.xml',
        'views/project_lists_info_views.xml',
        'views/training_courses_info_views.xml',
        'views/professional_info_views.xml',
        'views/training_courses_taught_views.xml',
        'views/project_info_views.xml',
    ]
}
