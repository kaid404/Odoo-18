# -*- coding: utf-8 -*-
{
    'name': "Milestone Results",
    'summary': "Milestone Results",
    'description': """Milestone Results""",
    'author': "Khalid",
    'company': 'Global XS Technology Solutions',
    'version': '18.0',
    'depends': ['base','gxs_core', 'gxs_milestone'],
    'data': [
        'security/ir.model.access.csv',
        'views/views.xml',
    ],
    'license': 'AGPL-3',
    'installable': True,
    'auto_install': False,
    'application': False,
}

