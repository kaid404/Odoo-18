from odoo import api, models, fields, api


class StudentPerformance(models.Model):
    _name = "milestone.std.performance"
    _rec_name = 'student_id'

    student_id = fields.Many2one('op.student', string="Student")
    campus_id = fields.Many2one('gxs.campus', string="Campus")
    section_id = fields.Many2one('class.section', string='Section')
    faculty_id = fields.Many2one('op.faculty', string="Faculty", related="section_id.faculty")
    class_id = fields.Many2one('op.academic.year', string='Academic Class', store=True, copy=True, )
    attendance = fields.Float(string="Attendance %")
    remarks = fields.Char(string="Remarks")

    mobile = fields.Char(strint="Mobile", related='student_id.mobile')
    gr_no = fields.Char(strint="Registration No", related='student_id.gr_no')

    year_id = fields.Many2one('op.academic.term', related="section_id.year_id", string='Academic Year', store=True,
                              copy=True, )
    subject_ids = fields.One2many('milestone.std.performance.line', 'profoma_id', string="Wiz")


class StudentPerformanceLine(models.Model):
    _name = "milestone.std.performance.line"

    profoma_id = fields.Many2one('milestone.std.performance', string="Performance")
    subject_id = fields.Many2one('op.subject', 'Subject', required=False)
    mid_result = fields.Float(string="Mid Result")
    final_result = fields.Float(string="Final Result")
    mid_marks_weightage = fields.Float('Mid Weightage (%)')

    def open_details(self):
        pass

    def action_result(self):
        return {
            'type': "ir.actions.act_window",
            'view_type': 'form',
            'view_mode': "list,form",
            # "target": 'new',
            'res_model': "milestone.std.result",
            'domain': [('std_performance_line_id', '=', self.id)]
        }


class OpSubjectRegistration(models.Model):
    _inherit = "op.subject.registration"

    @api.constrains('state')
    def create_performance_2(self):
        for rec in self:
            print('...........................')
            if rec.state == 'approved' and rec.course_id.is_milestone_course == True:

                data = {
                    'student_id': rec.student_id.id,
                    'campus_id': rec.student_id.x_camp_id.id,
                    # 'faculty_id': rec.student_id.faculty.id,
                    'section_id': rec.student_id.section_id.id,
                    'class_id': rec.student_id.year_id.id,
                    'campus_id': rec.student_id.x_camp_id.id,
                    'year_id': rec.student_id.class_id.id}
                head = self.env['milestone.std.performance'].create(data)

                for subject in rec.compulsory_subject_ids:
                    line_date = {
                        'subject_id': subject.id,
                        'profoma_id': head.id, }
                    line = self.env['milestone.std.performance.line'].create(line_date)

                    result_data = {
                        'std_performance_line_id': line.id,
                        'subject_id': subject.id,
                        'student_id': rec.student_id.id,
                        'section_id': rec.student_id.section_id.id,
                        'campus_id': rec.student_id.x_camp_id.id,
                        # 'faculty_id': rec.student_id.faculty.id,
                        'class_id': rec.student_id.year_id.id,
                        'year_id': rec.student_id.section_id.year_id.id,
                        'std_performance_id': head.id,
                    }

                    result = self.env['milestone.std.result'].create(result_data)

                    for subject_line in subject.assessment_component_ids_ml:
                        print(subject_line.assessment_type_id,'>>>>>>>>>>>')
                        subject_line_data = {
                            'std_result_id': result.id,
                            'assessment_type_id': subject_line.assessment_type_id.id,
                            'exam_type': subject_line.exam_type.id,
                            # 'total_marks': subject_line.total_marks,
                            # 'weightage': subject_line.weightage,
                            # 'min': subject_line.min,
                            # 'max': subject_line.max,
                        }
                        result_lines = self.env['milestone.std.result.line'].create(subject_line_data)

                        details_list = []
                        # for details_line in subject_line.assessment_type_id.subline_ids:
                        for details_line in subject_line.assessment_type_id.subline_ids:
                            detail_data = {
                                #'result_line_id': details_line.assessment_name,
                                 'subline_marks_id': details_line.id,
                                # 'sequence': details_line.sequence,
                                # 'total_marks': details_line.total_marks,
                                # 'weightage': details_line.weightage,
                            }
                            details_list.append((0, 0, detail_data))

                        result_lines.write({'result_line_details_id': details_list})


class StudentResult(models.Model):
    _name = "milestone.std.result"
    _rec_name = 'student_id'
    _inherit = ['mail.thread', 'mail.activity.mixin']

    std_performance_id = fields.Many2one('milestone.std.performance', string='Performance Id')
    std_performance_line_id = fields.Many2one('milestone.std.performance.line', string='Performance Id')
    subject_id = fields.Many2one('op.subject', 'Subject', required=False)

    student_id = fields.Many2one('op.student', string="Student")
    section_id = fields.Many2one('class.section', string='Section')
    campus_id = fields.Many2one('gxs.campus', string="Campus")
    faculty_id = fields.Many2one('op.faculty', string="Faculty", related="section_id.faculty")

    class_id = fields.Many2one('op.academic.year', string='Academic Class', store=True, copy=True,
                               related='section_id.class_id')

    mobile = fields.Char(strint="Mobile", related='student_id.mobile')
    gr_no = fields.Char(strint="Mobile", related='student_id.gr_no')

    year_id = fields.Many2one('op.academic.term', string='Academic Year', store=True, copy=True,
                              related="section_id.year_id")
    std_result_lines_id = fields.One2many('milestone.std.result.line', 'std_result_id', string='Result Lines', readonly=False)


class StudentResultLines(models.Model):
    _name = "milestone.std.result.line"

    std_result_id = fields.Many2one('milestone.std.result', string='Result')

    assessment_type_id = fields.Many2one('milestone.assessment.template.line', 'Assessment Type')
    exam_type = fields.Many2one('op.exam.type', 'Exam Type')
    total_marks = fields.Float('Total Marks')
    weightage = fields.Float('Weightage (%)')
    obtained_marks = fields.Float('Obtained Marks')
    min = fields.Float('Min (%)')
    max = fields.Float('Max (%)')

    result_line_details_id = fields.One2many('milestone.std.result.line.details', 'result_line_id',
                                             string='Result Lines Details', readonly=False)

    def action_result_lines_details(self):
        self.ensure_one()
        return {
            'type': 'ir.actions.act_window',
            'name': 'Result Line Details',
            'res_model': 'milestone.std.result.line',
            'view_mode': 'form',
            'res_id': self.id,
            'target': 'current'
        }


class StudentResultSub(models.Model):
    _name = "milestone.std.result.line.details"

    result_line_id = fields.Many2one('milestone.std.result.line', string='Result Line')
    # subline_marks_id = fields.Many2one('milestone.assessment.subline.marks', 'Subline Marks')
    subline_marks_id = fields.Many2one('milestone.assessment.template.subline', 'Subline Marks')
    sequence = fields.Integer('Sequence')
    # remarks = fields.Char('Remarks')
    obtained_marks = fields.Float('Obtained Marks')
    total_marks = fields.Float('Total Marks')
    weightage = fields.Float('Weightage')
    result_date = fields.Date(string="Result Date")
    milestone_rating = fields.Selection([
        ('working_towards', 'Working Towards'),
        ('working_at', 'Working At'),
        ('working_beyond', 'Working Beyond'),
    ], string='Milestone Rating', required=False)

