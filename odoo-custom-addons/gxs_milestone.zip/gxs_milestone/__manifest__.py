# -*- coding: utf-8 -*-
{
    'name': "Milestone",
    'summary': "Milestone Assessment",
    'description': """Milestone Assessment""",
    'author': "Khalid",
    'company': 'Global XS Technology Solutions',
    'version': '18.0',
    'depends': ['odoocms_academic','gxs_core', 'gxs_exam'],
    'data': [
        'security/ir.model.access.csv',
        'views/course_views.xml',
        'views/assessment_subline.xml',
        'views/assessment_temp.xml',
        'views/subject.xml',
        'views/academic_term.xml',
    ],
    'license': 'AGPL-3',
    'installable': True,
    'auto_install': False,
    'application': False,
}

