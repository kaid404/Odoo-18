from odoo import models, fields, api, _
from odoo.exceptions import ValidationError, UserError
import pdb
from odoo.osv import expression
from odoo.tools.safe_eval import safe_eval
import numpy as np
import pandas as pd
import math
from datetime import date, datetime

import plotly.figure_factory as ff
import plotly
import plotly.express as px
import plotly.graph_objs as go

import tempfile
import binascii
import xlrd

import logging

_logger = logging.getLogger(__name__)


def round_half_up(n, decimals=0):
    multiplier = 10 ** decimals
    return math.floor(n * multiplier + 0.5) / multiplier


import io

try:
    import xlwt
except ImportError:
    _logger.debug('Cannot `import xlwt`.')

try:
    import cStringIO
except ImportError:
    _logger.debug('Cannot `import cStringIO`.')

try:
    import base64
except ImportError:
    _logger.debug('Cannot `import base64`.')
READONLY_STATES = {
    'draft': [('readonly', False)],
    'current': [('readonly', True)],
    'lock': [('readonly', True)],
    'submit': [('readonly', True)],
    'disposal': [('readonly', True)],
    'approval': [('readonly', True)],
    'done': [('readonly', True)],
}
READONLY_STATES2 = {
    'draft': [('readonly', False)],
    'current': [('readonly', False)],
    'lock': [('readonly', True)],
    'submit': [('readonly', True)],
    'disposal': [('readonly', True)],
    'approval': [('readonly', True)],
    'done': [('readonly', True)],
}


class OpSubject(models.Model):
    _inherit = "op.subject"

    assessment_template_id_ml = fields.Many2one('milestone.assessment.template', 'Milestone Assessment Template',
                                             states=READONLY_STATES)

    assessment_component_ids_ml = fields.One2many('milestone.assessment.component', 'op_subject',
                                               compute='_compute_assessment_component_ids_milestone', string='Assessment Types',
                                               store=True, readonly=False)

    # @api.constrains('assessment_component_ids')
    # def validate_sum(self):
    #     for rec in self:
    #         total = sum(ass.weightage for ass in rec.assessment_component_ids)
    #         if total > 100:
    #             raise ValidationError('Weightage for %s can not be greater than 100' % (rec.name,))
    #         elif total > 0 and total < 100:
    #             raise ValidationError('Weightage for %s can not be less than 100' % (rec.name,))

    @api.depends('assessment_template_id_ml')
    def _compute_assessment_component_ids_milestone(self):
        for rec in self:
            template = rec.assessment_template_id_ml
            components = [[5]]
            for component in template.line_ids:
                cdata = {
                    'assessment_type_id': component.id,
                    'exam_type': component.exam_type.id,
                    # 'weightage': component.weightage,
                    # 'min': component.min,
                    # 'max': component.max,
                }
                components.append((0, 0, cdata))
            rec.assessment_component_ids_ml = components


class OdooCMSAssessmentComponent(models.Model):
    _name = 'milestone.assessment.component'
    _description = 'Assessment Class'
    _rec_name = 'assessment_type_id'
    _order = 'assessment_type_id'

    op_subject = fields.Many2one('op.subject', 'Class')
    assessment_type_id = fields.Many2one('milestone.assessment.template.line', 'Milestone Assessment Type')
    exam_type = fields.Many2one('op.exam.type', 'Exam Type')
    assessment_type_name = fields.Char(related='assessment_type_id.name', store=True)
    # final = fields.Boolean(related='assessment_type_id.final', store=True)
    # total_marks = fields.Float('Total Marks')
    # weightage = fields.Float('Weightage (%)')
    # min = fields.Float('Min (%)')
    # max = fields.Float('Max (%)')
    to_be = fields.Boolean(default=False)
