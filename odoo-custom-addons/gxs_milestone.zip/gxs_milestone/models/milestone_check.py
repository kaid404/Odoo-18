from odoo import fields, api, models

class OpCourse(models.Model):
    _inherit = "op.course"

    is_milestone_course = fields.Boolean(string='Is Milestone', default=False)

    @api.constrains('is_milestone_course')
    def _onchange_is_milestone_course(self):
        if self.is_milestone_course:
            for subject in self.subject_ids:
                subject.is_milestone_subject = True
        else:
            for subject in self.subject_ids:
                subject.is_milestone_subject = False

class OpSubject(models.Model):
    _inherit = "op.subject"

    is_milestone_subject = fields.Boolean(string='Is Milestone', default=False)

