from odoo import models, fields, api, _
from odoo.exceptions import ValidationError, UserError
import logging

_logger = logging.getLogger(__name__)


class OdooCMSAssessmentsSublineMarks(models.Model):
    _name = 'milestone.subline.marks'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _description = 'Assessment Template Subline Marks'
    _rec_name = 'name'

    name = fields.Char(string='Name', store=True, tracking=True)
    # marks = fields.Float(string="Total Marks", store=True, tracking=True)
