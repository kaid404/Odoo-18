from odoo import models, fields, api, _
from odoo.exceptions import ValidationError, UserError
import pdb
from odoo.osv import expression
from odoo.tools.safe_eval import safe_eval
import numpy as np
import pandas as pd
import math
from datetime import date, datetime

import plotly.figure_factory as ff
import plotly
import plotly.express as px
import plotly.graph_objs as go

import tempfile
import binascii
import xlrd

import logging

_logger = logging.getLogger(__name__)


def round_half_up(n, decimals=0):
    multiplier = 10 ** decimals
    return math.floor(n * multiplier + 0.5) / multiplier


import io

try:
    import xlwt
except ImportError:
    _logger.debug('Cannot `import xlwt`.')

try:
    import cStringIO
except ImportError:
    _logger.debug('Cannot `import cStringIO`.')

try:
    import base64
except ImportError:
    _logger.debug('Cannot `import base64`.')

READONLY_STATES = {
    'draft': [('readonly', False)],
    'current': [('readonly', True)],
    'lock': [('readonly', True)],
    'submit': [('readonly', True)],
    'disposal': [('readonly', True)],
    'approval': [('readonly', True)],
    'done': [('readonly', True)],
}

READONLY_STATES2 = {
    'draft': [('readonly', False)],
    'current': [('readonly', False)],
    'lock': [('readonly', True)],
    'submit': [('readonly', True)],
    'disposal': [('readonly', True)],
    'approval': [('readonly', True)],
    'done': [('readonly', True)],
}


class OdooCMSAssessmentTemplate(models.Model):
    _name = 'milestone.assessment.template'
    _description = 'Milestone Assessment Template'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _order = 'sequence'

    sequence = fields.Integer('Sequence')
    name = fields.Char('Template Name', required=True)
    code = fields.Char('Template Code', required=True)
    domain = fields.Char('Domain')
    component = fields.Selection([
        ('lab', 'Lab'),
        ('lecture', 'Lecture'),
        ('studio', 'Studio'),
    ], string='Component', required=False)

    line_ids = fields.One2many('milestone.assessment.template.line', 'template_id', 'Distribution Lines')
    # total = fields.Float('Total', compute='_get_total', store=True)
    detail_ids = fields.One2many('milestone.assessment.template.detail', 'template_id', 'Distribution Template')

    _sql_constraints = [
        ('name_uniq', 'unique(name)', "Template Name already exists!"),
        ('code_uniq', 'unique(code)', "Template Code already exists!"),
    ]

    # @api.depends('line_ids', 'line_ids.weightage')
    # def _get_total(self):
    #     for rec in self:
    #         total = 0
    #         for line in rec.line_ids:
    #             total += line.weightage
    #         if total > 100:
    #             raise ValidationError('Weightage for %s can not be greater than 100' % (rec.name,))
    #         rec.total = total


# Quiz=10, Assignments=15, Mid=25, Final=50  (Master)
class OdooCMSAssessmentTemplateLine(models.Model):
    _name = 'milestone.assessment.template.line'
    _description = 'Assessment Type'
    _order = 'sequence'

    sequence = fields.Integer('Sequence')
    name = fields.Char('Milestone Name', required=True)
    code = fields.Char('Milestone Code', required=True)
    # total_marks = fields.Float('Total Marks', required=True)
    # weightage = fields.Float('Weightage (%)', required=True)
    # min = fields.Float('Min (%)', required=True)
    # max = fields.Float('Max (%)', required=True)
    # final = fields.Boolean('Final', default=False)
    exam_type = fields.Many2one('op.exam.type', 'Exam Type', required=True)

    template_id = fields.Many2one('milestone.assessment.template', 'Distribution Template', ondelete='cascade')
    # component = fields.Selection('Component', related='template_id.component', store=True, help='Lecture/ Lab')
    subline_ids = fields.One2many('milestone.assessment.template.subline', 'template_line_id', 'Assessment Sublines')

    detail_line_ids = fields.One2many(
        'milestone.assessment.template.detail',
        'assessment_type_id',
        string='Assessment Details'
    )
    #
    @api.depends('name')
    def _compute_detail_line_ids(self):
        for line in self:
            line.detail_line_ids = self.env['milestone.assessment.template.detail'].search([
                ('assessment_type_id', '=', line.id)
            ])


    # @api.constrains('min', 'max', 'weightage')
    # def validate_range(self):
    #     for rec in self:
    #         if rec.min < 0:
    #             raise ValidationError(_('Min must be a Positive value'))
    #         if rec.max > 100:
    #             raise ValidationError(_('Max must be <= 100'))
    #         if rec.weightage < rec.min or rec.weightage > rec.max:
    #             raise ValidationError(_('Weightage must be in Min & Max range'))


class OdooCMSAssessmentTemplateDetail(models.Model):
    _name = 'milestone.assessment.template.detail'
    _description = 'Milestone Template Detail'
    # _rec_name = 'assessment_name'
    _order = 'sequence'

    template_id = fields.Many2one('milestone.assessment.template', 'Assessment Template')
    assessment_type_id = fields.Many2one('milestone.assessment.template.line', 'Assessment Type')
    # max_marks = fields.Float('Max Marks')
    # weightage = fields.Float('Weightage')
    sequence = fields.Integer('Sequence')
    result_date = fields.Date('Date')

class OdooCMSAssessmentTemplateSubLine(models.Model):
    _name = 'milestone.assessment.template.subline'
    _description = 'Assessment Type'
    _rec_name = 'assessment_name'
    _order = 'sequence'

    template_line_id = fields.Many2one('milestone.assessment.template.line', 'Assessment Template Line')
    subline_marks_id = fields.Many2one('milestone.subline.marks', 'Subline Marks')
    sequence = fields.Integer('Sequence')
    assessment_name = fields.Char('Milestone Name')
    assessment_code = fields.Char('Milestone Code')

