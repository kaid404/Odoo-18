from odoo import models, fields, api, _
from odoo.exceptions import ValidationError, UserError
from datetime import date, datetime
import logging

_logger = logging.getLogger(__name__)


class OpAcademicTerm(models.Model):
    _inherit = 'op.academic.term'

    op_academic_term_lines_ml = fields.One2many('milestone.academic.term.line', 'op_academic_term_id', 'Op Academic Term Lines')


class OpAcademicTermLine(models.Model):
    _name = 'milestone.academic.term.line'
    _description = 'Op Academic Term Line'

    op_academic_term_id = fields.Many2one('op.academic.term', 'Op Academic Term')
    term_schedule = fields.Selection([('r_s_d','Result Submission Deadline')], string='Term Schedule')
    date_from = fields.Date(string="From")
    date_to = fields.Date(string="To")
