{
    'name': 'Wallet Payment',
    'version': '18.0',
    'author': 'Saad Ahmad',
    'category': 'Accounting',
    'depends': ['base'],
    'data': [
        'security/ir.model.access.csv',
        'views/view.xml',
    ],
    'installable': True,
    'application': True,
}
