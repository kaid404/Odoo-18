from xmlrpc.client import ServerProxy

import xmlrpc.client
#howpaid
#posdetail

url = 'http://localhost:1800'
db = 'odoo18'
username = 'saad'
password = '000'
print('dddddddddddddddddddddddssssssss')
try:
    common = xmlrpc.client.ServerProxy(f"{url}/xmlrpc/2/common",allow_none=True)
    models = xmlrpc.client.ServerProxy(f"{url}/xmlrpc/2/object",allow_none=True)
    uid = common.authenticate(db, username, password, {})
    print(f'Connected')

    md = models.execute_kw(db, uid, password, 'wal.product', 'search', [
        [('wellmart_id', '=', )]])
    data = {'partner_id':'partner_id','amount':100}
    new_field_id = models.execute_kw(db, uid, password, 'wal.payment', 'create', [data])
except Exception as e:
    print(f'Connection Refused{e}')