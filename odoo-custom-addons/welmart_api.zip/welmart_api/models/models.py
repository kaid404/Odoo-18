from odoo import models, fields, api

import requests
from lxml import etree
from datetime import datetime
from odoo import models, fields, api
from odoo.exceptions import UserError
import logging

_logger = logging.getLogger(__name__)


class PosHeaderLines(models.Model):
    _name = 'pos.header.lines'
    _description = 'Pos Header lines'

    qty = fields.Float(string="Quantity", required=True)
    price = fields.Float(string="Price", required=True)
    discount = fields.Float(string="Discount", required=True)
    product_id = fields.Many2one('wal.product', string="Product")
    pos_header_id = fields.Many2one('pos.header', string="Product")
    line_total = fields.Float(compute='line_total_price', string="Total Price", store=True)

    shop_id = fields.Many2one('shop.info', string='Shop Info')

    @api.depends('qty', 'price', 'discount', 'product_id')
    def line_total_price(self):
        if self.pos_header_id:
            for rec in self:
                rec.line_total = (rec.qty * rec.price) - rec.discount


class WalletPayment(models.Model):
    _name = 'pos.header'
    _description = 'Pos Header'
    _rec_name = 'reference'

    reference = fields.Char(string='Order Id')
    # reference = fields.Char(string="Reference", required=True, copy=False, default=lambda self: self.env['ir.sequence'].next_by_code('wal.payment'))
    partner_id = fields.Char(string="Customer", required=False)
    payment_date = fields.Date(string="Payment Date")

    member_id = fields.Many2one('wal.members', string="Customer")
    shop_id = fields.Many2one('shop.info', string='Shop Info')
    pos_header_lines = fields.One2many('pos.header.lines', 'pos_header_id', string="Pos Header Lines")

    sub_total = fields.Float(compute='compute_sub_total_price', string="Untaxed Amount", store=True)

    tax_1 = fields.Float(string='Tax 1')
    tax_2 = fields.Float(string='Tax 2')
    tax_3 = fields.Float(string='Tax 3')
    tax_4 = fields.Float(string='Tax 4')
    tax_5 = fields.Float(string='Tax 5')

    total_tax = fields.Float(compute='compute_sub_total_price', string='Tax Amount')

    net_total = fields.Float(compute='compute_sub_total_price', string='Total Amount')

    @api.depends('pos_header_lines')
    def compute_sub_total_price(self):
        for rec in self:
            rec.sub_total = sum(line.line_total for line in rec.pos_header_lines)
            rec.total_tax = (rec.tax_1 + rec.tax_2 + rec.tax_3 + rec.tax_4 + rec.tax_5)
            rec.net_total = rec.sub_total + rec.total_tax



    # state = fields.Selection([
    #     ('draft', 'Draft'),
    #     ('confirm', 'Confirmed'),
    #     ('done', 'Done'),
    #     ('cancel', 'Cancelled')
    # ], string="Status", default='draft')

    def send_to_jordan_tax_authority(self):
        """
        Send the invoice to Jordan Tax Authority in XML format compliant with UPL 2.1 standard
        """
        # API endpoint
        api_url = "https://backend.jofotara.gov.jo/core/invoices/-00010"

        for invoice in self:
            # if invoice.move_type not in ('out_invoice', 'out_refund'):
            #     continue  # Only send customer invoices and credit notes

            try:
                # Generate XML content
                xml_content = self._generate_jordan_invoice_xml(invoice)

                # Validate XML structure before sending
                self._validate_xml(xml_content)

                # Store digital copy locally (as required)
                self._store_invoice_copy(invoice, xml_content)

                # Send to tax authority
                headers = {
                    'Content-Type': 'application/xml',
                    'Accept': 'application/xml'
                }

                response = requests.post(
                    api_url,
                    data=xml_content,
                    headers=headers,
                    timeout=30
                )

                if response.status_code == 200:
                    _logger.info(f"Invoice {invoice.reference} successfully sent to Jordan Tax Authority")
                    invoice.message_post(body="Invoice successfully submitted to Jordan Tax Authority")
                else:
                    error_msg = f" {xml_content}Failed to send invoice {invoice.reference}. Status: {response.status_code}, Response: {response.text}"
                    _logger.error(error_msg)
                    raise UserError(error_msg)

            except Exception as e:
                error_msg = f"Error sending invoice {invoice.reference} to Jordan Tax Authority: {str(e)}"
                _logger.error(error_msg)
                raise UserError(error_msg)

    def _generate_jordan_invoice_xml(self, invoice):
        """
        Generate XML content compliant with UPL 2.1 standard
        """
        # Create XML root element
        root = etree.Element("Invoice", xmlns="urn:oasis:names:specification:ubl:schema:xsd:Invoice-2")

        # Add basic invoice information
        etree.SubElement(root, "ID").text = invoice.reference  # Invoice Number
        etree.SubElement(root, "IssueDate").text = invoice.payment_date.strftime("%d.%m.%Y")  # DD.MM.YYYY format

        # Add seller information
        seller_party = etree.SubElement(root, "AccountingSupplierParty")
        party = etree.SubElement(seller_party, "Party")
        etree.SubElement(party, "Name").text = "Del Monte Foods / Jordan"

        postal_address = etree.SubElement(party, "PostalAddress")
        etree.SubElement(postal_address,
                         "StreetName").text = "Salama Abu Sanad, 2nd Floor, Bldg.#39, Albayader, Amman, Jordan"

        party_tax_scheme = etree.SubElement(party, "PartyTaxScheme")
        etree.SubElement(party_tax_scheme, "CompanyID", schemeID="VAT").text = "17802120"

        # Add customer information if available
        if invoice.partner_id:
            buyer_party = etree.SubElement(root, "AccountingCustomerParty")
            customer_party = etree.SubElement(buyer_party, "Party")
            etree.SubElement(customer_party, "Name").text = invoice.partner_id or "Optional"

            # if invoice.partner_id.vat:
            #     customer_tax_scheme = etree.SubElement(customer_party, "PartyTaxScheme")
            #     etree.SubElement(customer_tax_scheme, "CompanyID",
            #                      schemeID="VAT").text = invoice.partner_id.vat or "Optional"

            if invoice.partner_id:
                customer_tax_scheme = etree.SubElement(customer_party, "PartyTaxScheme")
                etree.SubElement(customer_tax_scheme, "CompanyID",
                                 schemeID="VAT").text = '98937978783' or "Optional"

        # Add invoice lines
        invoice_lines = etree.SubElement(root, "InvoiceLines")
        for line in invoice.pos_header_lines:
            invoice_line = etree.SubElement(invoice_lines, "InvoiceLine")
            etree.SubElement(invoice_line, "ID").text = str(line.id)

            item = etree.SubElement(invoice_line, "Item")
            etree.SubElement(item,
                             "Description").text = line.product_id.name or line.product_id.name  # Item Description

            price = etree.SubElement(invoice_line, "Price")
            etree.SubElement(price, "PriceAmount", currencyID=self.env.company.currency_id.name).text = str(
                line.price)

            quantity = etree.SubElement(invoice_line, "InvoicedQuantity", unitCode="EA").text = str(
                line.qty)  # Quantity

            line_total = etree.SubElement(invoice_line, "LineExtensionAmount",
                                          currencyID=self.env.company.currency_id.name).text = str(
                (line.price * line.qty) - line.discount)

        # Add tax totals
        tax_total = etree.SubElement(root, "TaxTotal")
        tax_amount = etree.SubElement(tax_total, "TaxAmount", currencyID=self.env.company.currency_id.name).text = str(
            abs(4446))  # Total GST Amt

        # Add legal totals
        legal_total = etree.SubElement(root, "LegalMonetaryTotal")
        etree.SubElement(legal_total, "LineExtensionAmount", currencyID=self.env.company.currency_id.name).text = str(
            5667)
        etree.SubElement(legal_total, "TaxExclusiveAmount", currencyID=self.env.company.currency_id.name).text = str(
            43456)
        etree.SubElement(legal_total, "TaxInclusiveAmount", currencyID=self.env.company.currency_id.name).text = str(
            56678)  # Total value of invoice
        etree.SubElement(legal_total, "PayableAmount", currencyID=self.env.company.currency_id.name).text = str(
            23457)

        # Convert to XML string
        xml_str = etree.tostring(
            root,
            pretty_print=True,
            encoding='UTF-8',
            xml_declaration=True
        )

        return xml_str

    def _validate_xml(self, xml_content):
        """
        Validate the generated XML (basic validation)
        """
        try:
            etree.fromstring(xml_content)
        except etree.XMLSyntaxError as e:
            raise UserError(f"Invalid XML generated: {str(e)}")

    def _store_invoice_copy(self, invoice, xml_content):
        """
        Store digital copy of the invoice XML as required
        """
        # Create an attachment
        pass
        # self.env['ir.attachment'].create({
        #     'name': f"Jordan_Tax_Invoice_{invoice.name}.xml",
        #     'datas': xml_content.encode('base64'),
        #     'res_model': 'account.move',
        #     'res_id': invoice.id,
        #     'type': 'binary',
        #     'mimetype': 'application/xml'
        # })

    def action_confirm(self):
        self.state = 'confirm'

    def action_done(self):
        self.state = 'done'

    def action_cancel(self):
        self.state = 'cancel'


class WalletProduct(models.Model):
    _name = 'wal.product'
    _description = 'Wallet Payment'

    name = fields.Char(string="Name", required=True)
    wellmart_id = fields.Char(string="ID", required=True)


class WalletMembers(models.Model):
    _name = 'wal.members'
    _description = 'Wallet Payment'

    name = fields.Char(string="Name", required=False)
    last_name = fields.Char(string="Last Name", required=False)
    number = fields.Char(string="Number", required=False)
    code = fields.Char(string="Code", required=False)

    shop_id = fields.Many2one('shop.info', string='Shop Info')



class ShopInfo(models.Model):
    _name = 'shop.info'
    _description = 'Wallet Payment'

    name = fields.Char(string="Name", required=False)
    address = fields.Char(string="Address", required=False)
    mac_ad = fields.Char(string="Mac Address", required=False)
    key = fields.Char(string="Key", required=False)
    clientID = fields.Char(string="ClientID", required=False)
